<?php session_start() ?>
<!DOCTYPE html>                            <!-- -->
<html>
    <head>
        <meta charset="utf-8" />
        <link rel="stylesheet" href="../style_accueil.css" />
        <title>Gamer's Way</title>
    </head>

	<?php include("../header.php"); ?>

	<body>
		
	</body>

    <?php include("../footer.php"); ?>
    
</html>